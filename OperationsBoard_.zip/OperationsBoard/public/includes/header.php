<?php
$sql = "SELECT id,fname,lname,oname,gender,job_position,email,address,phone,level,avatar,date_created FROM user WHERE email ='{$_SESSION["email"]}' AND id='{$_SESSION["id"]}' LIMIT 1";
$query = $database->query($sql);
$userdata = $database->fetch_array($query);					
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Operations Management</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="assets/plugins/datatables/dataTables.bootstrap.css">
  <!-- Web style -->
  <link rel="stylesheet" href="assets/css/Operation.css">
  <!-- Skin -->
  <link rel="stylesheet" href="assets/css/skins/skin-blue.css">
  <link rel="stylesheet" href="assets/css/fancy.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <a href="home" class="navbar-brand"><b>OPERATIONS</b>Dashboard</a>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div> 
        <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Ongoing Operations <span class="sr-only">(current)</span></a></li>
            <li class="dropdown">
              <a href="streps.php" class="dropdown-toggle" data-toggle="dropdown">Sitreps <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="streps?str=Spot">Spot</a></li>
                <li class="divider"></li>
                <li><a href="streps?str=Six_hours">Six Hours</a></li>
                <li class="divider"></li>
                <li><a href="streps?str=Daily">Daily</a></li>
                <li class="divider"></li>
                <li><a href="streps?str=Weekly">Weekly</a></li>
                <li class="divider"></li>
                <li><a href="streps?str=Monthly">Monthly</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">General Profile <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="personal-profile.php">Personal profile</a></li>
                <li class="divider"></li>
                <li><a href="pax.php">Group profile</a></li>
                <li class="divider"></li>
                <li><a href="pax">Organisation profile</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Elements/People/Group O.I <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="personal-profile.php">Personal profile</a></li>
                <li class="divider"></li>
                <li><a href="pax">Group profile</a></li>
                <li class="divider"></li>
                <li><a href="pax">Organisation profile</a></li>
              </ul>
            </li> 
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="all-users.php">All users</a></li>
                <li class="divider"></li>
                <li><a href="add-a-user.php">New user</a></li>
                <li class="divider"></li>
                <li><a href="#">logs</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-collapse -->
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- Notifications Menu -->
            <li class="dropdown notifications-menu">
              <!-- Menu toggle button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i> 
                <span class="label label-warning">2</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 2 notifications</li>
                <li>
                  <!-- Inner Menu: contains the notifications -->
                  <ul class="menu">
                    <li><!-- start notification -->
                      <a href="streps">
                        <i class="fa fa-users text-aqua"></i> 2 new streps today
                      </a>
                    </li>
                    <!-- end notification -->
                  </ul>
                </li>
                <li class="footer"><a href="streps">View all</a></li>
              </ul>
            </li>
            <!-- Tasks Menu -->
            <!-- User Account Menu -->
            <li class="dropdown user user-menu">
              <!-- Menu Toggle Button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <!-- The user image in the navbar-->
                <img src="assets/img/user160x60.jpg" class="user-image" alt="User Image">
                <!-- hidden-xs hides the username on small devices so only the image appears. -->
                <span class="hidden-xs"><?php echo $userdata['lname'][0].'.'.$userdata['fname']; ?></span>
              </a>
              <ul class="dropdown-menu">
                <!-- The user image in the menu -->
                <li class="user-header">
                  <img src="assets/img/user160x60.jpg" class="img-circle" alt="User Image">

                  <p>
                    <?php echo $userdata['lname'].' '.$userdata['fname'].' - '.$userdata['job_position']; ?>
                    <small>Member since <?php $dateCreated = explode(' ', $userdata['date_created']); echo $dateCreated[0]; ?></small>
                  </p>
                </li>
                <!-- Menu Body -->
                
                <!-- Menu Footer-->
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="general-profile?op_u=<?php echo $userdata['id']; ?>" class="btn btn-default btn-flat">Profile</a>
                  </div>
                  <div class="pull-right">
                    <a href="logout" class="btn btn-default btn-flat">Sign out</a>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- /.navbar-custom-menu -->
      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>
  <!-- Full Width Column -->