<?php
//DATABASE CONSTANTS
 defined("DB_SERVE")? NULL : DEFINE("DB_SERVE","fezzo");
 defined("DB_USER")? NULL : DEFINE("DB_USER","fezzo");
 defined("DB_PASS")? NULL : DEFINE("DB_PASS","AdminDB");
 defined("DB_NAME")? NULL : DEFINE("DB_NAME","opms");
?>