 <?php  include"includes/header.php" ?>
 <div class="content-wrapper">
    <div class="container">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 class="textarea">
            <!-- Ongoing Operations -->
          <small class="external-event bg-green ui-draggable ui-draggable-handle" >Ongoing Operations</small>
        </h1>
        <ol class="breadcrumb hidden-xs">
          <li><a href="home.php"><i class="fa fa-dashboard"></i> Ongoing Operations</a></li>
        </ol>
      </section>

            <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="assets/img/user.jpg" alt="User profile picture">

              <h3 class="profile-username text-center">M. Amudala Eric</h3>
              <p class="text-muted text-center">Software Engineer</p>
              <a href="#" class="btn btn-primary btn-block"><b>Send a message</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary" style="padding: 5px">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Education</strong>

              <p class="text-muted">
                B.S. in Computer Science from the University of Rwanda at Huye
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>

              <p class="text-muted">Kigali, Rwanda</p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>

              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Activities</a></li>
              <li><a href="#timeline" data-toggle="tab">My Posts</a></li>
              <li class="hidden-xs"><a href="#newOperation" data-toggle="tab">Add a new operation</a></li>
              <li class="hidden-xs"><a href="#newStrips" data-toggle="tab">Add a new Strips</a></li>
              <li class="hidden-xs"><a href="#settings" data-toggle="tab">User Settings</a></li>
              <li class="hidden-xs"><a href="#Password" data-toggle="tab">Change your Password</a></li>
            </ul>
            <div class="tab-content">
              <!-- Activity Tab -->
              <div class="active tab-pane" id="activity" style="padding: 20px">
                <!-- Post -->
                <div class="post">
                  <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="assets/img/user.jpg" alt="user image">
                        <span class="username">
                          <a href="#">Operation number one</a>
                          <!-- <a href="#" class="pull-right btn-box-tool"><i class="fa fa-clock-o"></i> 7:30</a> -->
                        </span>
                    <span class="description">Ongoing operation posted on August 05 2018 - 7:00 AM</span>
                  </div>
                  <!-- /.user-block -->
                  <p>
                    Lorem ipsum represents a long-held tradition for designers,
                    typographers and the like. Some people hate it and argue for
                    its demise, but others ignore the hate as they create awesome
                    tools to help create filler text for everyone from bacon lovers
                    to Charlie Sheen fans.
                  </p>
                  <ul class="list-inline">
                    <li>Posted by <a href="general-profile.php" class="link-black text-sm" style="color:rgba(60, 141, 188, 1);"><i class="fa fa-user margin-r-5"></i> M. Amudala Eric</a></li>
                    <li><a href="#" class="link-black text-sm"><span class="label label-lg label-success"><b>READ MORE DETAILS</b></span></a></li> 
                    <li><a href="#" class="link-black text-sm"><span class="label label-lg label-primary"><b>DOWNLOAD ATTACHMENT</b></span></a></li> 
                    <li class="pull-right" id="com1">
                      <a class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                        (3)</a></li>
                  </ul>
                </div>
                <!-- /.post -->
                <div class="item" id="com_area" style="display:none;">
                  <div class="box box-success" style="border-top: none;">
                    <div class="box-body chat" id="chat-box">
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User One
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User Two
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User Three
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                    </div>
                    <!-- /.chat -->
                    <div class="box-footer">
                       <form class="form-horizontal">
                        <div class="form-group margin-bottom-none">
                          <div class="col-sm-9">
                            <input class="form-control input-sm" placeholder="Response">
                          </div>
                          <div class="col-sm-3">
                            <button type="submit" class="btn btn-danger pull-right btn-block btn-sm">Send</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
              </div>
              <!-- /.post -->
                              <!-- Post -->
                <div class="post">
                  <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="assets/img/user.jpg" alt="user image">
                        <span class="username">
                          <a href="#">Operation number two</a>
                          <!-- <a href="#" class="pull-right btn-box-tool"><i class="fa fa-times"></i></a> -->
                        </span>
                    <span class="description">Ongoing operation posted on August 05 2018 - 7:00 AM</span>
                  </div>
                  <!-- /.user-block -->
                  <p>
                    Lorem ipsum represents a long-held tradition for designers,
                    typographers and the like. Some people hate it and argue for
                    its demise, but others ignore the hate as they create awesome
                    tools to help create filler text for everyone from bacon lovers
                    to Charlie Sheen fans.
                  </p>
                  <ul class="list-inline">
                    <li>Posted by <a href="#" class="link-black text-sm" style="color:rgba(60, 141, 188, 1);"><i class="fa fa-user margin-r-5"></i> R. Anicet</a></li>
                    <li><a href="general-profile.php" class="link-black text-sm"><span class="label label-lg label-success"><b>READ MORE DETAILS</b></span></a></li> 
                    <li class="pull-right" onclick="show_comments2()">
                      <a class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                        (2)</a></li>
                  </ul>
                </div>
                <!-- /.post -->
                <div class="item" id="com_area2" style="display:none;">
                  <div class="box box-success" style="border-top: none;">
                    <div class="box-body chat" id="chat-box">
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User One
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User Three
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                    </div>
                    <!-- /.chat -->
                    <div class="box-footer">
                       <form class="form-horizontal">
                        <div class="form-group margin-bottom-none">
                          <div class="col-sm-9">
                            <input class="form-control input-sm" placeholder="Response">
                          </div>
                          <div class="col-sm-3">
                            <button type="submit" class="btn btn-danger pull-right btn-block btn-sm">Send</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
              </div>
              <!-- /.post -->
                              <!-- Post -->
                <div class="post">
                  <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="assets/img/user.jpg" alt="user image">
                        <span class="username">
                          <a href="#">Operation number three</a>
                          <!-- <a href="#" class="pull-right btn-box-tool"><i class="fa fa-times"></i></a> -->
                        </span>
                    <span class="description">Ongoing operation posted on August 05 2018 - 7:00 AM</span>
                  </div>
                  <!-- /.user-block -->
                  <p>
                    Lorem ipsum represents a long-held tradition for designers,
                    typographers and the like. Some people hate it and argue for
                    its demise, but others ignore the hate as they create awesome
                    tools to help create filler text for everyone from bacon lovers
                    to Charlie Sheen fans.
                  </p>
                  <ul class="list-inline">
                    <li>Posted by <a href="#" class="link-black text-sm" style="color:rgba(60, 141, 188, 1);"><i class="fa fa-user margin-r-5"></i> K. Felix</a></li>
                    <li class="pull-right" onclick="show_comments3()">
                      <a class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                        (1)</a></li>
                    <li><a href="#" class="link-black text-sm"><span class="label label-lg label-success"><b>READ MORE DETAILS</b></span></a></li>    
                  </ul>
                </div>
                <!-- /.post -->
                <div class="item" id="com_area3" style="display:none;">
                  <div class="box box-success" style="border-top: none;">
                    <div class="box-body chat" id="chat-box">
                      <!-- chat item -->
                      <div class="item" style="background-color: #f4f4f4;border-radius: 3px;padding: 10px;margin-top: 5px">
                        <img class="img-circle" alt="user image" src="assets/img/user.jpg">

                        <p class="message">
                          <a class="name" href="#">
                            <small class="text-muted pull-right"><i class="fa fa-clock-o"></i> 5:15</small>
                            User Three
                          </a>
                          I would like to meet you to discuss the latest news about
                          the arrival of the new theme. They say it is going to be one the
                          best themes on the market
                        </p>
                      </div>
                      <!-- /.item -->
                    </div>
                    <!-- /.chat -->
                    <div class="box-footer">
                       <form class="form-horizontal">
                        <div class="form-group margin-bottom-none">
                          <div class="col-sm-9">
                            <input class="form-control input-sm" placeholder="Response">
                          </div>
                          <div class="col-sm-3">
                            <button type="submit" class="btn btn-danger pull-right btn-block btn-sm">Send</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
              </div>
              <!-- /.post -->
              </div>
              <!-- /.End of Activity-pane -->

              <!-- My post-pane  -->
              <div class="tab-pane" id="timeline" style="padding: 20px">
                <!-- The post -->
                <ul class="timeline timeline-inverse">
                  <!-- post item -->
                  <li>
                    <i class="fa fa-file-text-o bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 7:00 AM</span>

                      <h3 class="timeline-header"><a href="#">Operation number one </a></h3>

                      <div class="timeline-body">
                        Lorem ipsum represents a long-held tradition for designers, typographers and the like. Some people hate it and argue for its demise, but others ignore the hate as they create awesome tools to help create filler text for everyone from bacon lovers to Charlie Sheen fans.
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Add attachment</a>
                        <a class="btn btn-danger btn-xs">Edit Post</a>
                        <a class="btn btn-success btn-xs">View full Post</a>
                      </div>
                    </div>
                  </li>
                  <!-- END post item -->
                  <!-- Post item -->
                  <li>
                    <i class="fa fa-file-text-o bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

                      <h3 class="timeline-header"><a href="#">Operation number 0</a></h3>

                      <div class="timeline-body">
                        Lorem ipsum represents a long-held tradition for designers, typographers and the like. Some people hate it and argue for its demise, but others ignore the hate as they create awesome tools to help create filler text for everyone from bacon lovers to Charlie Sheen fans.
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Add attachment</a>
                        <a class="btn btn-danger btn-xs">Edit Post</a>
                        <a class="btn btn-success btn-xs">View full Post</a>
                      </div>
                    </div>
                  </li>
                  <!-- END Post item -->
                </ul>
              </div>
              <!-- /.End of my post-pane -->

              <!-- Add a new post-pane  -->
              <div class="tab-pane" id="newOperation" style="padding: 20px">
                <form id="add_operation" method="POST" action="#" enctype="multipart/form-data" novalidate="novalidate">
                      <fieldset>
                        <div class="row">
                          <div class="form-group">
                            <div class="col-md-6 col-sm-6">
                              <label>Operation Title <span class="text-danger">*</span></label>
                              <input type="text" name="o_title" id="o_title" value="" class="form-control required" placeholder="Type operation title here">
                            </div>
                            <div class="col-md-6 col-sm-6">
                              <label>Attachmen if any</label>
                              <div class="fancy-file-upload fancy-file-info">
                                <i class="fa fa-upload"></i>
                                <input type="file" class="form-control" onchange="jQuery(this).next('input').val(this.value);">
                                <input type="text" class="form-control required" id="user_pic" name="user_pic" placeholder="no file selected" readonly="">
                                <span class="button">Choose File</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row" style="margin-top: 5px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label>Details </label>
                              <textarea class="form-control" rows="7" name="o_details" id="o_details" placeholder="Type operation details here"></textarea>
                            </div>
                          </div>
                        </div>

                         <!-- <div class="row" style="margin-top: 15px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label for="o_type">Operation Type</label>
                            <select class="form-control" name="sel_op_type" id="sel_op_type">
                              <option value="">--- Select operation type ---</option>
                              <option value="1">Ongoing Operation</option>
                              <option value="2">Strips</option>
                            </select>
                            </div>
                          </div>
                        </div> -->
                        
                        <div class="row" style="margin-top: 15px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label>Operation Remarks </label>
                              <textarea class="form-control" rows="4" name="0_remark" id="0_remark" placeholder="Type operation remark here"></textarea>
                            </div>
                          </div>
                        </div>  
                        
                        <div class="row" style="margin-top: 15px">
                        <div class="col-md-12">
                          <button type="submit" class="btn btn-3d btn-primary btn-xlg btn-block margin-top-30" name="newusr">
                            CREATE OPERATION
                          </button>
                        </div>
                      </div> 
                    </fieldset>
                  </form>

              </div>
              <!-- /.End of add a new post-pane -->



               <!-- Add a new Strips-pane  -->
              <div class="tab-pane" id="newStrips" style="padding: 20px">
                <form id="add_operation" method="POST" action="#" enctype="multipart/form-data" novalidate="novalidate">
                      <fieldset>
                        <div class="row">
                          <div class="form-group">
                            <div class="col-md-6 col-sm-6">
                              <label>Subject <span class="text-danger">*</span></label>
                              <input type="text" name="s_subject" id="s_subject" value="" class="form-control required" placeholder="Type sitreps title here">
                            </div>
                            <div class="col-md-6 col-sm-6">
                              <label>Attachmen if any</label>
                              <div class="fancy-file-upload fancy-file-info">
                                <i class="fa fa-upload"></i>
                                <input type="file" class="form-control" onchange="jQuery(this).next('input').val(this.value);">
                                <input type="text" class="form-control required" id="str_attach" name="str_attach" placeholder="no file selected" readonly="">
                                <span class="button">Choose File</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row" style="margin-top: 5px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label>Details </label>
                              <textarea class="form-control" rows="6" name="str_detail" id="str_detail" placeholder="Type sitreps details here"></textarea>
                            </div>
                          </div>
                        </div>

                        <div class="row" style="margin-top: 15px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label for="o_type">Spot</label>
                              <input type="text" class="form-control" name="s_spot" id="s_spot" placeholder="Enter spot here">
                            </select>
                            </div>
                          </div>
                        </div> 
                        
                        <div class="row" style="margin-top: 15px">
                          <div class="form-group">
                            <div class="col-md-12 col-sm-12">
                              <label>Sitreps Remarks </label>
                              <textarea class="form-control" rows="3" name="0_remark" id="0_remark" placeholder="Type operation remark here"></textarea>
                            </div>
                          </div>
                        </div> 
                        
                        <div class="row" style="margin-top: 15px">
                        <div class="col-md-12">
                          <button type="submit" class="btn btn-3d btn-primary btn-xlg btn-block margin-top-30" name="newusr">
                            CREATE OPERATION
                          </button>
                        </div>
                      </div> 
                    </fieldset>
                  </form>

              </div>
              <!-- /.End of add a new Strips-pane -->


              <!-- Settings-Pane -->
              <div class="tab-pane" id="settings" style="padding: 20px">
                <form class="form-horizontal" id="user_form" action="#" method="post" >
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">First Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control required" id="inputName" placeholder="First Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label required">Middle Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputMname" placeholder="Middle name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="lname" class="col-sm-2 control-label required">Last Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputLname" placeholder="Last name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="jtitle" class="col-sm-2 control-label required">Job Title</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputJob" placeholder="Job Title">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="school" class="col-sm-2 control-label required">School</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSchool" placeholder="Eg : UR">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="school" class="col-sm-2 control-label required">School Level</label>

                    <div class="col-sm-10">
                      <select class="form-control required" id="selectSchool">
                        <option value="">--- Select level ---</option>
                        <option value="PhD">PhD</option>
                        <option value="Masters">Masters</option>
                        <option value="A0">A0</option>
                        <option value="A1">A1</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="jtitle" class="col-sm-2 control-label required">Department</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputDepartment" placeholder="Eg : Computer Science">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="gender" class="col-sm-2 control-label required">Gender</label>

                    <div class="col-sm-10">
                      <select class="form-control required" id="selectGender">
                        <option value="">--- Select gender ---</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Telephone No.</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control required" id="inputTel" placeholder="Phone Number">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Address</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control required" id="inputAdd" placeholder="Home Location">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Update Details</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.End of my settings-pane -->

              <!-- Change my password -->
              <div class="tab-pane" id="Password" style="padding: 20px">
                <form class="form-horizontal" id="user_form" action="#" method="post" >
                  <div class="form-group">
                    <label for="o_password" class="col-sm-2 control-label">Old Password</label>

                    <div class="col-sm-10">
                      <input type="password" class="form-control required" id="o_password" placeholder="Enter your current password">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="n_password" class="col-sm-2 control-label required">New Password</label>

                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="n_password" placeholder="Enter your new password">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="r_password" class="col-sm-2 control-label required">Repeast Password</label>

                    <div class="col-sm-10">
                      <input type="password" class="form-control" id="r_password" placeholder="Repeat your new password">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Update Password</button>
                    </div>
                  </div>
                </form>  
              </div>

            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
      
    </div>
    <!-- /.container -->
  </div>
  <!-- /.content-wrapper -->
 <?php  include"includes/footer.php" ?>  
 