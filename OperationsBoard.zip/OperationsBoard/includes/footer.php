 <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <!-- <b>Version</b> 2.3.8 -->
      </div>
      <strong>Copyright &copy; 2018 <a href="#">OPERATIONSBoard</a>.</strong> All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<!-- DataTables -->
<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- Operation App -->
<script src="assets/js/app.min.js"></script>
<script src="assets/js/demo.js"></script>
<script type="text/javascript">

  // function show_comments(argument) {
  //   $('#com_area').show();
  // }
  // function show_comments3(argument) {
  //   $('#com_area3').show();
  // }
  //   function show_comments2(argument) {
  //   $('#com_area2').show();
  // }

$(document).ready(function(){
  $('#com1').on("click", function(){
    $('#com_area').toggle(300);
  });
});

</script>
<script type="text/javascript">
 $(document).ready(function(){
  $('#viewAll').on("click", function(){
    $('#more_members').toggle(1000);
  });
 });
</script>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
</body>
</html>
