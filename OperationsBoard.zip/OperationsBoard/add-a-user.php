<?php  include"includes/header.php" ?>
  <!-- Full Width Column -->
  <div class="content-wrapper">
    <div class="container">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1 class="textarea">
          <!-- USER REGISTRATION -->
          <small></small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="home.php"><i class="fa fa-dashboard"></i> Ongoing Operation</a></li>
          <li class="active">User Registration</li>
        </ol>
      </section>
    <!-- Main content -->
    <section class="content">

      <div class="row">
          <div class="box box-warning">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="panel-body">

                  <h4>How it's working?</h4>
                  <p>To register a user successfuly, you must fill all the field with a red star, after the registration you will receive a successful registration message to make sure the registration has been completed successfully.</p>
                  <hr>
                  <h4>Edit a user</h4>
                  <p>
                    If you want to edit a user please click on this button <br><br>
                    <a href="all-users.php" class="btn btn-info btn-xs">Edit user</a>
                  </p>

                </div>
                </div>
                <div class="col-md-8">
                  <div class="panel-body">
                    <form id="add_user" method="POST" action="#" enctype="multipart/form-data" novalidate="novalidate">
                            <fieldset>
                              <div class="row">
                                <div class="form-group">
                                  <div class="col-md-6 col-sm-6">
                                    <label>First Name <span class="text-danger">*</span></label>
                                    <input type="text" name="user_fname" value="" class="form-control required">
                                  </div>
                                  <div class="col-md-6 col-sm-6">
                                    <label>Last Name <span class="text-danger">*</span></label>
                                    <input type="text" name="user_lname" value="" class="form-control required">
                                  </div>
                                </div>
                              </div>

                              <div class="row" style="margin-top: 7px">
                                <div class="form-group">
                                  <div class="col-md-12 col-sm-12">
                                    <label>Other name </label>
                                    <input type="text" name="o_name" id="o_name" value="" class="form-control ">
                                  </div>
                                </div>
                              </div>

                              <div class="row" style="margin-top: 7px">
                                <div class="form-group">
                                  <div class="col-md-6 col-sm-6">
                                    <label>Gender <span class="text-danger">*</span></label>
                                    <select name="user_gn" id="user_gn" class="form-control pointer required">
                                      <option value="">--- Select Gender---</option>
                                      <option value="1">Male</option><option value="2">Female</option>                              </select>
                                  </div>
                                  <div class="col-md-6 col-sm-6">
                                    <label>Job Position <span class="text-danger">*</span></label>
                                    <input type="text" name="job_title" id="job_title" class="form-control required">
                                  </div>
                                </div>
                              </div>
                              <div class="row" style="margin-top: 7px">
                                <div class="form-group">
                                  <div class="col-md-12 col-sm-12">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input type="email" name="user_email" id="user_email" value="" class="form-control nbrs required">
                                    <span id="id_message"></span>
                                  </div>
                                </div>
                              </div>
                              <div class="row" style="margin-top: 7px">
                                <div class="form-group">
                                  <div class="col-md-6 col-sm-6">
                                    <label>Phone Number <span class="text-danger">*</span></label>
                                    <input type="text" name="user_phone" id="user_phone" value="" class="form-control nbrs required">
                                    <span id="p_message"></span>
                                    
                                  </div>
                                  <div class="col-md-6 col-sm-6">
                                    <label>Address (Location) <span class="text-danger">*</span></label>
                                    <input type="text" name="user_add" id="user_add" class="form-control required">                          
                                  </div>
                                </div>
                              </div>
                              <div class="row" style="margin-top: 7px">
                                <div class="form-group">
                                  <div class="col-md-12 col-sm-6">
                                    <label>User Status <span class="text-danger">*</span></label>
                                    <select name="user_role" id="user_role" class="form-control pointer required">
                                      <option value="">--- Select status ---</option>
                                      <option value="Important">Important</option>
                                      <option value="Normal">Normal</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </fieldset>
                            <!-- <fieldset style="display: none ; margin-top: 13px" id="pass_field">
                              <div class="row">
                                <div class="form-group">
                                  <div class="col-md-6 col-sm-6">
                                    <label>Username <span class="text-danger">*</span></label>
                                    <input type="text" name="username" id="username" class="form-control ">
                                  </div>
                                  <div class="col-md-6 col-sm-6">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input type="email" name="email" id="email" class="form-control required">
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="form-group">
                                  <div class="col-md-6 col-sm-6">
                                    <label>Password <span class="text-danger">*</span></label>
                                    <input type="password" name="user_pass" id="user_pass" value="" class="form-control ">
                                    
                                  </div>
                                  <div class="col-md-6 col-sm-6">
                                    <label>Repeat Password <span class="text-danger">*</span></label>
                                    <input type="password" name="user_pass_rep" id="user_pass_rep" value="" onkeyup="check()" class="form-control ">
                                  </div>
                                </div>
                              </div>
                              <div class="row" style="margin-bottom: 0px;padding-top: 10px;">
                                <div class="col-md-12" id="message_pass" style="margin-bottom: -20px">
                                    
                                </div>
                              </div>
                            </fieldset> -->
                            <hr>
                            <div class="row">
                              <div class="col-md-12">
                                <button type="submit" class="btn btn-3d btn-warning btn-xlg btn-block" name="newusr">
                                  CREATE USER
                                </button>
                              </div>
                            </div>
                          </form>
                        </div>  
                </div>
              </div>  
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
      
    </div>
    <!-- /.container -->
  </div>
  <!-- /.content-wrapper -->
 <?php  include"includes/footer.php" ?>
