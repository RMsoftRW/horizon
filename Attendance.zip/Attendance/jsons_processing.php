<?php
header("Content-Type: application/json; charset=UTF-8");
// $obj = json_decode($_GET["x"], false);

$conn = new mysqli("localhost", "root", "AdminDB", "attendance");
$result = $conn->query("SELECT m.* FROM members AS m,users AS u,files AS f WHERE f.id=m.img AND m.idnumber= '".$_GET['editable_u']."' LIMIT 1");
// $result = $conn->query("SELECT m.*,f.data FROM members AS m,users AS u,files AS f WHERE f.id=m.img AND m.idnumber= '".$_GET["x"]."' LIMIT 1");
$outp = array();
$outp = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($outp);
?>