<?php
		$msg = '';
		$a1 = array();
		if (session_status() == PHP_SESSION_NONE) {
			session_start();
		}

		$fname			= '';
		$lname			= '';
		$mname			= '';
		$user_gn		= '';
		$user_status	= '';
		$id_num			= '';
		$user_add		= '';
		$site			= '';
		$role			= '';
		$username		= '';
		$email			= '';
		$password		= '';
		$password1		= '';
	if ((!empty($_GET['editable_u']) && isset($_GET['editable_u'])) && $_SESSION['page'] == 'edit') {
		require_once 'includes/init.php';
		$a = $_GET['editable_u'];
		echo(json_encode(getEditable($a)));
	}elseif (isset($_POST['s_changes']) && $_SESSION['page'] == 'edit') {

		$data	= $database->escape_value($_POST['id']);
		$data	.= '|' .$database->escape_value($_POST['user_fname']);
		$data	.= '|' .$database->escape_value($_POST['user_lname']);
		$data	.= '|' .$database->escape_value($_POST['o_name']);
		$data	.= '|' .$database->escape_value($_POST['user_gn']);
		$data	.= '|' .$database->escape_value($_POST['user_pos']);
		$data	.= '|' .$database->escape_value($_POST['id_num']);
		$data	.= '|' .$database->escape_value($_POST['user_phone']);
		$data	.= '|' .$database->escape_value($_POST['user_add']);
		$data	.= '|' .$database->escape_value($_POST['user_site']);
		$data	.= '|' .$database->escape_value($_POST['user_role']);
		$data	.= '|' .$database->escape_value($_POST['username']);
		$data	.= '|' .$database->escape_value($_POST['email']);
		$data	.= '|' .$database->escape_value($_POST['user_pass']);
		$data	.= '|' .$database->escape_value($_POST['user_pass_rep']);
		editUser($data,$_SESSION['authId'],$_FILES);
	}elseif ((!empty($_GET['pd']) && isset($_GET['pd'])) &&( $_SESSION['page'] == 'addP' || $_SESSION['page'] =='set')) {
		require_once 'includes/init.php';
		getPd('get',$_GET['pd']);
	}elseif ((!empty($_GET['ps']) && isset($_GET['ps'])) &&( $_SESSION['page'] == 'addP' || $_SESSION['page'] =='set')) {
		require_once 'includes/init.php';
		getPs('get',$_GET['ps']);
	}elseif (isset($_POST['newpr'])) {

		$data	= $database->escape_value($_POST['p_name']);
		$data	.= '|' .$database->escape_value($_POST['p_province']);
		$data	.= '|' .$database->escape_value($_POST['pd']);
		$data	.= '|' .$database->escape_value($_POST['ps']);
		$data	.= '|' .$database->escape_value($_POST['pdetail']);
		AddNewProj($data);
	}else{
	}
	if (isset($_SESSION['page']) && $_SESSION['page'] == 'edit') {
			$page = 'edit';
			// getData();
		}elseif(isset($_SESSION['page']) && $_SESSION['page'] == 'scan'){
			$page = 'scan';
			getData();
		}else{
		}
	function getmedude()
	{
		global $page;
		getData();
	}

	function getData()
	{
		global $database;
		global $page;
		$data = GetUserInfo();
		$x =1;

		while ($row = $database->fetch_array($data)) {

			if ($page == 'edit') {
				
				$action = '<span><button class="label label-sm label-info" data-toggle="modal" data-target="#myModal" onclick=\'setsession('.$row["idnumber"].')\'>Edit user</button></span>';
			}elseif ($page == 'scan') {
				
				$action = '<span>
								<form method="POST" action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'">
									<input type="hidden" value="'.$row["idnumber"].'" name="scodes" >
									<input type="hidden" value="" name="c_in[]" id="status" >
									<button class="label label-sm label-success">Approve Attendance</button>
								</form>
								</span>';
			}
			
			if ($row['data']) {
				$img = '<img width="80" style = " height : 53px !important" class="img img-responsive" src="data:'.$row['mime'].';base64,' . base64_encode( $row['data'] ) . '"  alt="picture" />';
			}else{

				$img = '<img  width="80" style = " height : 53px !important" class="img img-responsive" src="assets/images/user_attendance.jpg" alt="picture" />';
			}
			echo '
				<tr class="odd gradeX">
										<td>
											<input type="checkbox" class="checkboxes" value="'.$row['id'].'"/>
										</td>
										<td>
											<figure class="margin-bottom-10"><!-- image -->
												'.$img.'
											</figure>
											 
										</td>
										<td style="padding: 20px ">
											'.$row['lname'].' '.$row['mname'].' '.$row['fname'].'
										</td>
										<td style="padding: 20px ">
											 '.$row['phone'].'
										</td>
										<td style="padding: 20px ">
											'.GetPosition($row['position']).'
										</td>
										<td style="padding: 20px ">
											'.$action.'
										</td>
									</tr>';

			$x++;
		}
		// echo json_encode($output);
	}