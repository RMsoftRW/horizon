<?php

// Autoloader
require_once 'proj/libs/bootstrap.php';
require_once 'proj/libs/controller.php';
require_once 'proj/libs/view.php';

$app = new Bootstrap();