<?php include_once 'includes/init.php'; ?>
<?php $_SESSION['page'] = 'addP'; ?>
<?php include 'getD.php'; ?>
<?php include_once 'includes/header.php'; ?>
<?php include_once 'includes/nav.php'; ?>
<?php include_once 'includes/top_menu.php'; ?>

			<!-- 
				MIDDLE 
			-->
			<section id="middle">


				<!-- page title -->
				<header id="page-header">
					<h1>Project Registration</h1>
					<ol class="breadcrumb">
						<li><a href="scan.php">Scan</a></li>
						<li class="active">Project Registration</li>
					</ol>
				</header>
				<!-- /page title -->


				<div id="content" class="padding-20">


					<div class="row">
						<div class="col-md-12"><?php echo($msg); ?></div>
						
						<div class="col-md-7">
						
							<!-- ------ -->
							<div class="panel panel-default">
								<div class="panel-heading panel-heading-transparent">
									<strong>Project Registration form</strong>
								</div>

								<div class="panel-body">

										<form id="add_user" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data" >
											<fieldset>
												<!-- required [php action request] -->
												<!-- <input type="hidden" name="action" value="contact_send" /> -->

												<div class="row">
													<div class="form-group">
														<div class="col-md-6 col-sm-12">
															<label>Project Name <span class="text-danger">*</span></label>
															<input type="text" name="p_name" value="" class="form-control required" value="">
														</div>
														<div class="col-md-6">
															<label>Project Location/ Province <span class="text-danger">*</span></label>
															<select name="p_province" id="p_province" value="" class="form-control required" onchange="changeD(this)" >
																<option value="">--- Select a province ---</option>
																<?php GetV('prov'); ?>
															</select>
													</div>
													</div>
												</div>
												<div class="row">
													<div class="form-group">
														<div class="col-md-6">
																<label>Project District <span class="text-danger">*</span></label>
																<select name="pd" id="pd" value="" class="form-control required"  onchange="changeS(this)">
																	<option value="">--- Select a district ---</option>
																	
																</select>
														</div>
														<div class="col-md-6">
																<label>Project Sector <span class="text-danger">*</span></label>
																<select name="ps" id="ps" value="" class="form-control required">
																	<option value="">--- Select a sector ---</option>
																	
																</select>
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-12">
															<label>Project Details <span class="text-danger">*</span></label>
															<textarea name="pdetail" id="" rows="5" value="" class="form-control required"></textarea>
													</div>
												</div>
											</fieldset>
											<div class="row">
												<div class="col-md-12">
													<button type="submit" class="btn btn-3d btn-teal btn-xlg btn-block margin-top-30" name="newpr">
														CREATE PROJECT
													</button>
												</div>
											</div>

										</form>

								</div>

							</div>
							<!-- /----- -->

						</div>
						<div class="col-md-5">
							<div class="panel panel-default">
								<div class="panel-body">

									<h4>How it's working?</h4>
									<p>To register a project successfuly, you must fill and selet locations, after the registration you will receive a successful registration message to make sure the project has been completed successfully.</p>
									<hr />
									<h4>Edit a project</h4>
									<p>
										If you want to edit a project please click on this button <br><br>
										<a href="edit-user.php"  class="btn btn-info btn-xs">Edit project</a>
									</p>

								</div>
							</div>

						</div>

					</div>

				</div>
			</section>
			<!-- /MIDDLE -->

		</div>
<?php include 'includes/footer.php'; ?>
	
