Color Picker
https://bgrins.github.io/spectrum/