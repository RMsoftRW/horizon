<!DOCTYPE html>
<html>
<body>

<h2>Get data as JSON from a PHP file on the server.</h2>

<p>The JSON received from the PHP file:</p>

<p id="demo"></p>

<script>
var obj, dbParam, xmlhttp;
// obj = { "editable_u":2, "limit":10 };
// dbParam = JSON.stringify(obj);
xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        document.getElementById("demo").innerHTML = this.responseText;
        // alert('');
    }
};
xmlhttp.open("GET", "json_demo_db_post.php?x=2", true);
xmlhttp.send();

</script>

</body>
</html>
