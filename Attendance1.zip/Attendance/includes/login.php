<?php
    // require_once 'config.php';
    // include 'includes/datab.php';
    // include 'includes/functions.php';
    $errors = [];
    $username = "";
    $pass = "";
    $msg1 = "";
    if (isset($_SESSION['authId'])) {
        redirect_to(ROOT."/scan.php");
    }else{
        if (isset($_POST['submt']) && !empty($_POST['usname']) && !empty($_POST['psswd'])) {
            if (login($_POST['usname'], $_POST['psswd'])) {
                redirect_to(ROOT."/scan.php");
            }else{
                redirect_to(ROOT."/");
            }
        }
    }