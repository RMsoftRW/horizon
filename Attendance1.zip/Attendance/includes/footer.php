<!-- JAVASCRIPT FILES -->
		<script type="text/javascript">var plugin_path = 'assets/plugins/';</script>
		<script type="text/javascript" src="assets/plugins/jquery/jquery-2.2.3.min.js"></script>
		<script type="text/javascript" src="assets/plugins/jquery/jquery.session.js"></script>
		<script type="text/javascript" src="assets/js/app.js"></script>
		<script src="assets/js/jquery.validate.js"></script>
		<script type="text/javascript" src="assets/js/custom.js"></script>

		<!-- ID codes foeld -->
		<script type="text/javascript">
			$(document).ready(function(){
				$('#scodes').focus();
			});
		</script>


		<!-- Forms Validation -->
		<script type="text/javascript">
			$('#add_user').validate();
			$('#codeform').validate();
			$('#ed_user').validate();
			$('#event_cr').validate();
			$('#event_ed').validate();
			$('#site_cr').validate();
			$('#site_ed').validate();
			$('#pos_cr').validate();
			$('#pos_ed').validate();
			$('#f_attend').validate();
		</script>
		<!-- End of forms Validation -->
		<!-- Admin registration form -->
		<script type="text/javascript">

			function show_form(){	            
	            var a = $('#user_role').val();
	            if (a == '2' || a == '3') {
	            	$('#username').addClass('required');
					$('#user_pass').addClass('required');
					$('#user_pass_rep').addClass('required');
	            	$("#pass_field").show(1000);
				}	
				if (a == '1'){
					$('#username').removeClass('required');
					$('#user_pass').removeClass('required');
					$('#user_pass_rep').removeClass('required');
					$("#pass_field").hide(1000);
				}            
	        }
		</script>
		<!-- End of Admin registration form -->
		<!-- Password match Validation -->
		<script type="text/javascript">

			function check(){
				var p = $('#user_pass').val();
		  		var rp = $('#user_pass_rep').val();

		  		if (p !== rp) {
					$("#message_pass").html("<p class='alert alert-mini alert-danger text-center'><strong> Sorry!</strong> your passwords dont match, try again</p>");
						exit();

				}else{
					$("#message_pass").html("<p class='alert alert-mini alert-success text-center'><strong> Well done!</strong> your passwords match</p>");
				}
			}
		</script>
		<!-- End of Admin password match Validation -->
		<!-- ID and Phone validaltion -->
		<script type="text/javascript">
			$( ".nbrs" )
			  .keyup(function() {
			  	var b = $('#user_phone').val();
			  	var a = $('#id_num').val();
			  	if (isNaN(a)) {
					$( "#id_message" ).html("<p style='margin-bottom: 0px;' class='alert alert-mini alert-danger text-center'><strong> Sorry! </strong> ID must be numbers only, try again</p>");
					
				} 
				else if (isNaN(b)) {
					$( "#p_message" ).html("<p style='margin-bottom: 0px;' class='alert alert-mini alert-danger text-center'><strong> Sorry! </strong>Enter Numbers only</p>");
				}else{
					$( "#p_message" ).html("<p style='display:none'></p>");
					$( "#id_message" ).html("<p style='display:none'></p>");
					exit();
				}
		  })
		</script>
		<!-- End of ID and Phone validaltion -->

		<!--  -->
		<script type="text/javascript">
			function setsession(argument='') {
				var obj, dbParam, xmlhttp, myObj, x, txt="";
				// obj = { "editable_u":2, "limit":10 };
				// dbParam = JSON.stringify(obj);
				xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				    if (this.readyState == 4 && this.status == 200) {
				        myObj = JSON.parse(this.responseText);
				        for (x in myObj) {
					        document.getElementById("id").value = myObj[x].id;
					        document.getElementById("fname").value = myObj[x].fname;
					        document.getElementById("lname").value = myObj[x].lname;
					        document.getElementById("o_name").value = myObj[x].mname;
					        document.getElementById("user_gn").value = myObj[x].sex;
					        document.getElementById("user_pos").value = myObj[x].position;
					        document.getElementById("id_num").value = myObj[x].idnumber;
					        document.getElementById("user_site").value = myObj[x].site;
					        document.getElementById("user_role").value = myObj[x].role;
					        document.getElementById("email").value = myObj[x].email;
					        document.getElementById("user_add").value = myObj[x].address;
					        document.getElementById("user_phone").value = myObj[x].phone;
				        }
				    }
				};
				xmlhttp.open("GET", "getD.php?editable_u="+argument, true);
				xmlhttp.send();

				// $.post("getD.php",{editable_u: argument},
				//         function(data,status){
				//         	var a= JSON.parse(this.data);
				//         	// alert('great');
				// 	            alert("Data: " + a.length + "\nStatus: " + status);
				//         });
			}

			function changeD(argument) {
					var obj, dbParam, xmlhttp, myObj, x, txt="";
				
				xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				    if (this.readyState == 4 && this.status == 200) {
				        document.getElementById("pd").innerHTML = this.responseText;
				    }
				};
				xmlhttp.open("GET", "getD.php?pd="+argument.value, true);
				xmlhttp.send();
			}

			function changeS(argument) {
				var obj, dbParam, xmlhttp, myObj, x, txt="";
				xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				    if (this.readyState == 4 && this.status == 200) {
				        document.getElementById("ps").innerHTML = this.responseText;
				    }
				};
				xmlhttp.open("GET", "getD.php?ps="+argument.value, true);
				xmlhttp.send();
			}
		</script>
		<!--  -->

		<script type="text/javascript">

		 	$(document).ready(function(){
		 	$('.ok').on("click", function(){
		 		// alert();
		 		var me = $('#ok1').val();
		 		var from = $('#ok2').val();
		 		var to = $('#ok3').val();
		 		window.open('http://localhost/attendance/user_logs.php?me='+me+'&from='+from+'&to='+to,'GoogleWindow', 'width=800, height=600');
		 	});
		 });	
		</script>


	</body>
</html>