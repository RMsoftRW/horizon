<?php
	
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	require_once 'config.php';
	require_once 'datab.php';
	require_once 'functions.php';
	require_once 'blob.php';
