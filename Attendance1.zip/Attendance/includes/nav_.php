<aside id="aside">
				
				<nav id="sideNav"><!-- MAIN MENU -->
					<ul class="nav nav-list">
						<li><img style="padding:10px" src="assets/images/logo_attendance.jpg" class="img img-responsive" alt="Attendance Card"></li>
						<li><a href="Scan.php"><i class="main-icon fa fa-book"></i>Scan</a></li>
						<li><a href="user-profile.php"><i class="main-icon fa fa-user"></i>User profile</a></li>
						<li class="">
							<a href="#">
								<i class="main-icon fa fa-users"></i>
								<i class="fa fa-menu-arrow pull-right"></i><span>Administration</span>
							</a>

							<ul><!-- submenus -->
								<!-- <li><a href="all-registered.php">Attendance</a></li> -->
								<li><a href="add-a-user.php">Add a new casual user</a></li>
								<li><a href="add-a-userc.php">Add a new system user</a></li>
								<li><a href="edit-user.php">Edit a user</a></li>
								<li><a href="settings.php">Edit Settings</a></li>
							</ul>

						</li>

						<li class="">
							<a href="#">
								<i class="main-icon fa fa-users"></i>
								<i class="fa fa-menu-arrow pull-right"></i><span>Reports</span>
							</a>

							<ul><!-- submenus -->
								<li><a href="all-registered.php">Attendance</a></li>
							</ul>

						</li>

				</nav>

				<span id="asidebg"><!-- aside fixed background --></span>
			</aside>
			<!-- /ASIDE -->